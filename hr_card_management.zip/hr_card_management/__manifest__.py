{
    'name': 'HR Card Management',
    'version': '10.0s',
    'description': """HR Card Management""",
    'author': 'Me',
    'website': 'https://www.mycompany.com',
    'category': 'HR',
    'depends': ['hr'],
    'data': ['views/hr_card_view.xml'],
    'demo': [],
    'installable': True,
    'auto_install': False,
}
